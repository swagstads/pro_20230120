<div id="goToTop" class="hidden-xs hidden-sm">
    <span class="fa fa-long-arrow-up"></span>
</div>
<div id="velaPreLoading">
    <span></span>
    <div class="velaLoading">
        <span class="velaLoadingIcon one"></span>
        <span class="velaLoadingIcon two"></span>
        <span class="velaLoadingIcon three"></span>
        <span class="velaLoadingIcon four"></span>
    </div>
</div>


<script
    src="cdn.shopify.com/shopifycloud/shopify/assets/themes_support/api.jquery-e94e010e92e659b566dbc436fdfe5242764380e00398907a14955ba301a4749f.js"
    type="text/javascript"></script>
<script src="cdn.shopify.com/s/files/1/1573/5553/t/43/assets/vendor93dd.js?v=138786516400658099071617237749"
    type="text/javascript"></script>
<script src="cdn.shopify.com/s/files/1/1573/5553/t/43/assets/vela_ajaxcart7578.js?v=53329818851908209301618026644"
    type="text/javascript"></script>
<script src="cdn.shopify.com/s/files/1/1573/5553/t/43/assets/lazysizes.min0a9f.js?v=153772683470722238621617237743"
    async="async"></script>
<script src="cdn.shopify.com/s/files/1/1573/5553/t/43/assets/vela755f.js?v=105199010723301478381618026699"
    type="text/javascript"></script>
<!-- Vendor JS Files -->
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script> 
<script src="assets/vendor/typed.js/typed.min.js"></script>

<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>
<script src="assets/js/script.js"></script>
<script src="assets/js/index.js"></script>