<div id="shopify-section-1600942022910" class="shopify-section velaFramework">
                <div class="velaLogoList mbGutter" style="background-color: rgba(0, 0, 0, 0); padding: 40px 0 90px">
                    <div class="container">
                        <div class="velaLogoListInner">
                            <div class="velaContent">
                                <div class="velaOwlRow owlCarouselPlay">
                                    <div class="owl-carousel" data-nav="true" data-loop="true" data-autoplay="false"
                                        data-autoplaytimeout="10000" data-columnone="5" data-columntwo="4"
                                        data-columnthree="3" data-columnfour="3" data-columnfive="2">
                                        <div class="item">
                                            <div class="logoImage d-flex flexJustifyCenter">
                                                <a href="#"><img class="img-responsive" alt="AtoZ"
                                                        src="https://cdn.shopify.com/s/files/1/1573/5553/files/logo_image1.png?v=1613719814" /></a>
                                            </div>
                                        </div>

                                        <div class="item">
                                            <div class="logoImage d-flex flexJustifyCenter">
                                                <a href="#"><img class="img-responsive" alt="AtoZ"
                                                        src="https://cdn.shopify.com/s/files/1/1573/5553/files/logo_image2.png?v=1613719814" /></a>
                                            </div>
                                        </div>

                                        <div class="item">
                                            <div class="logoImage d-flex flexJustifyCenter">
                                                <a href="#"><img class="img-responsive" alt="AtoZ"
                                                        src="https://cdn.shopify.com/s/files/1/1573/5553/files/logo_image3.png?v=1613719814" /></a>
                                            </div>
                                        </div>

                                        <div class="item">
                                            <div class="logoImage d-flex flexJustifyCenter">
                                                <a href="#"><img class="img-responsive" alt="AtoZ"
                                                        src="https://cdn.shopify.com/s/files/1/1573/5553/files/logo_image4.png?v=1613719815" /></a>
                                            </div>
                                        </div>

                                        <div class="item">
                                            <div class="logoImage d-flex flexJustifyCenter">
                                                <a href="#"><img class="img-responsive" alt="AtoZ"
                                                        src="https://cdn.shopify.com/s/files/1/1573/5553/files/logo_image5.png?v=1613719815" /></a>
                                            </div>
                                        </div>

                                        <div class="item">
                                            <div class="logoImage d-flex flexJustifyCenter">
                                                <a href="#"><img class="img-responsive" alt="AtoZ"
                                                        src="https://cdn.shopify.com/s/files/1/1573/5553/files/logo_image6.png?v=1613719815" /></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>