            <!-- Blogs -->
            <!-- <div id="shopify-section-1600942034460" class="shopify-section velaFramework">
                <div class="velaHomeBlogs mbGutter style1"
                    style="background-color: rgba(0, 0, 0, 0); padding: 0 0 40px">
                    <div class="container">
                        <div class="velaHomeBlogsInner">
                            <div class="headingGroup pb20">
                                <h3 class="velaHomeTitle text-center">
                                    <span>Our Blog Posts</span>
                                </h3>
                                <span class="subTitle">Mirum est notare quam littera gothica quam nunc putamus
                                    parum claram!</span>
                            </div>
                            <div class="velaContent">
                                <div class="velaOwlRow owlCarouselPlay">
                                    <div class="owl-carousel" data-nav="true" data-loop="false" data-dots="false"
                                        data-autoplay="false" data-autoplaytimeout="10000" data-columnone="3"
                                        data-columntwo="3" data-columnthree="2" data-columnfour="1" data-columnfive="1">
                                        <div class="velaBlogItem blogArticle">
                                            <div class="blogPostImage">
                                                <a href="blogs/news/anteposuerit-litterarum-formas-6.php"
                                                    title="Anteposuerit litterarum formas.">
                                                    <div class="p-relative">
                                                        <div class="product-card__image" style="padding-top: 64.375%">
                                                            <img class="product-card__img lazyload imgFlyCart"
                                                                data-src="https://cdn.shopify.com/s/files/1/1573/5553/articles/1_360x.jpg?v=1511574495"
                                                                data-widths="[360,540,720,900,1080,1296,1728,1944,2808,4320]"
                                                                data-aspectratio="1.5533980582524272"
                                                                data-ratio="1.5533980582524272" data-sizes="auto"
                                                                alt="Anteposuerit litterarum formas." />
                                                        </div>
                                                        <div class="placeholder-background placeholder-background--animation"
                                                            data-image-placeholder></div>
                                                    </div>
                                                </a>
                                            </div>

                                            <div class="blogPostContent">
                                                <div class="blogTitle">
                                                    <a href="blogs/news.php" title="News">News</a>
                                                </div>
                                                <h3 class="articleTitle">
                                                    <a href="blogs/news/anteposuerit-litterarum-formas-6.php">Anteposuerit
                                                        litterarum formas.</a>
                                                </h3>
                                                <div class="articleMeta d-flex">
                                                    <span class="articleAuthor"><span>By</span> Mr Admin</span>
                                                    <span>/</span>
                                                    <span class="articlePublish pull-left"><i class="fa fa-calendar-o"
                                                            aria-hidden="true"></i>November 16, 2017</span>
                                                </div>
                                                <div class="articleDesc">
                                                    Diga, Koma and Torus are three kitchen utensils
                                                    designed for Ommo, a new design-oriented...
                                                </div>
                                                <a class="btn btnBlogReadMore"
                                                    href="blogs/news/anteposuerit-litterarum-formas-6.php"
                                                    title="Read More">
                                                    Read More
                                                </a>
                                            </div>
                                        </div>

                                        <div class="velaBlogItem blogArticle">
                                            <div class="blogPostImage">
                                                <a href="blogs/news/anteposuerit-litterarum-formas-13.php"
                                                    title="Anteposuerit litterarum formas.">
                                                    <div class="p-relative">
                                                        <div class="product-card__image" style="padding-top: 64.375%">
                                                            <img class="product-card__img lazyload imgFlyCart"
                                                                data-src="https://cdn.shopify.com/s/files/1/1573/5553/articles/2_360x.jpg?v=1511574521"
                                                                data-widths="[360,540,720,900,1080,1296,1728,1944,2808,4320]"
                                                                data-aspectratio="1.5533980582524272"
                                                                data-ratio="1.5533980582524272" data-sizes="auto"
                                                                alt="Anteposuerit litterarum formas." />
                                                        </div>
                                                        <div class="placeholder-background placeholder-background--animation"
                                                            data-image-placeholder></div>
                                                    </div>
                                                </a>
                                            </div>

                                            <div class="blogPostContent">
                                                <div class="blogTitle">
                                                    <a href="blogs/news.php" title="News">News</a>
                                                </div>
                                                <h3 class="articleTitle">
                                                    <a href="blogs/news/anteposuerit-litterarum-formas-13.php">Anteposuerit
                                                        litterarum formas.</a>
                                                </h3>
                                                <div class="articleMeta d-flex">
                                                    <span class="articleAuthor"><span>By</span> Mr Admin</span>
                                                    <span>/</span>
                                                    <span class="articlePublish pull-left"><i class="fa fa-calendar-o"
                                                            aria-hidden="true"></i>November 06, 2017</span>
                                                </div>
                                                <div class="articleDesc">
                                                    Diga, Koma and Torus are three kitchen utensils
                                                    designed for Ommo, a new design-oriented...
                                                </div>
                                                <a class="btn btnBlogReadMore"
                                                    href="blogs/news/anteposuerit-litterarum-formas-13.php"
                                                    title="Read More">
                                                    Read More
                                                </a>
                                            </div>
                                        </div>

                                        <div class="velaBlogItem blogArticle">
                                            <div class="blogPostImage">
                                                <a href="blogs/news/anteposuerit-litterarum-formas-12.php"
                                                    title="Anteposuerit litterarum formas.">
                                                    <div class="p-relative">
                                                        <div class="product-card__image" style="padding-top: 64.375%">
                                                            <img class="product-card__img lazyload imgFlyCart"
                                                                data-src="https://cdn.shopify.com/s/files/1/1573/5553/articles/3_360x.jpg?v=1511574539"
                                                                data-widths="[360,540,720,900,1080,1296,1728,1944,2808,4320]"
                                                                data-aspectratio="1.5533980582524272"
                                                                data-ratio="1.5533980582524272" data-sizes="auto"
                                                                alt="Anteposuerit litterarum formas." />
                                                        </div>
                                                        <div class="placeholder-background placeholder-background--animation"
                                                            data-image-placeholder></div>
                                                    </div>
                                                </a>
                                            </div>

                                            <div class="blogPostContent">
                                                <div class="blogTitle">
                                                    <a href="blogs/news.php" title="News">News</a>
                                                </div>
                                                <h3 class="articleTitle">
                                                    <a href="blogs/news/anteposuerit-litterarum-formas-12.php">Anteposuerit
                                                        litterarum formas.</a>
                                                </h3>
                                                <div class="articleMeta d-flex">
                                                    <span class="articleAuthor"><span>By</span> Mr Admin</span>
                                                    <span>/</span>
                                                    <span class="articlePublish pull-left"><i class="fa fa-calendar-o"
                                                            aria-hidden="true"></i>November 06, 2017</span>
                                                </div>
                                                <div class="articleDesc">
                                                    Diga, Koma and Torus are three kitchen utensils
                                                    designed for Ommo, a new design-oriented...
                                                </div>
                                                <a class="btn btnBlogReadMore"
                                                    href="blogs/news/anteposuerit-litterarum-formas-12.php"
                                                    title="Read More">
                                                    Read More
                                                </a>
                                            </div>
                                        </div>

                                        <div class="velaBlogItem blogArticle">
                                            <div class="blogPostImage">
                                                <a href="blogs/news/anteposuerit-litterarum-formas-11.php"
                                                    title="Anteposuerit litterarum formas.">
                                                    <div class="p-relative">
                                                        <div class="product-card__image" style="padding-top: 64.375%">
                                                            <img class="product-card__img lazyload imgFlyCart"
                                                                data-src="https://cdn.shopify.com/s/files/1/1573/5553/articles/4_360x.jpg?v=1511574572"
                                                                data-widths="[360,540,720,900,1080,1296,1728,1944,2808,4320]"
                                                                data-aspectratio="1.5533980582524272"
                                                                data-ratio="1.5533980582524272" data-sizes="auto"
                                                                alt="Anteposuerit litterarum formas." />
                                                        </div>
                                                        <div class="placeholder-background placeholder-background--animation"
                                                            data-image-placeholder></div>
                                                    </div>
                                                </a>
                                            </div>

                                            <div class="blogPostContent">
                                                <div class="blogTitle">
                                                    <a href="blogs/news.php" title="News">News</a>
                                                </div>
                                                <h3 class="articleTitle">
                                                    <a href="blogs/news/anteposuerit-litterarum-formas-11.php">Anteposuerit
                                                        litterarum formas.</a>
                                                </h3>
                                                <div class="articleMeta d-flex">
                                                    <span class="articleAuthor"><span>By</span> Mr Admin</span>
                                                    <span>/</span>
                                                    <span class="articlePublish pull-left"><i class="fa fa-calendar-o"
                                                            aria-hidden="true"></i>November 06, 2017</span>
                                                </div>
                                                <div class="articleDesc">
                                                    Diga, Koma and Torus are three kitchen utensils
                                                    designed for Ommo, a new design-oriented...
                                                </div>
                                                <a class="btn btnBlogReadMore"
                                                    href="blogs/news/anteposuerit-litterarum-formas-11.php"
                                                    title="Read More">
                                                    Read More
                                                </a>
                                            </div>
                                        </div>

                                        <div class="velaBlogItem blogArticle">
                                            <div class="blogPostImage">
                                                <a href="blogs/news/anteposuerit-litterarum-formas-10.php"
                                                    title="Anteposuerit litterarum formas.">
                                                    <div class="p-relative">
                                                        <div class="product-card__image" style="padding-top: 64.375%">
                                                            <img class="product-card__img lazyload imgFlyCart"
                                                                data-src="https://cdn.shopify.com/s/files/1/1573/5553/articles/5_360x.jpg?v=1511574587"
                                                                data-widths="[360,540,720,900,1080,1296,1728,1944,2808,4320]"
                                                                data-aspectratio="1.5533980582524272"
                                                                data-ratio="1.5533980582524272" data-sizes="auto"
                                                                alt="Anteposuerit litterarum formas." />
                                                        </div>
                                                        <div class="placeholder-background placeholder-background--animation"
                                                            data-image-placeholder></div>
                                                    </div>
                                                </a>
                                            </div>

                                            <div class="blogPostContent">
                                                <div class="blogTitle">
                                                    <a href="blogs/news.php" title="News">News</a>
                                                </div>
                                                <h3 class="articleTitle">
                                                    <a href="blogs/news/anteposuerit-litterarum-formas-10.php">Anteposuerit
                                                        litterarum formas.</a>
                                                </h3>
                                                <div class="articleMeta d-flex">
                                                    <span class="articleAuthor"><span>By</span> Mr Admin</span>
                                                    <span>/</span>
                                                    <span class="articlePublish pull-left"><i class="fa fa-calendar-o"
                                                            aria-hidden="true"></i>November 06, 2017</span>
                                                </div>
                                                <div class="articleDesc">
                                                    Diga, Koma and Torus are three kitchen utensils
                                                    designed for Ommo, a new design-oriented...
                                                </div>
                                                <a class="btn btnBlogReadMore"
                                                    href="blogs/news/anteposuerit-litterarum-formas-10.php"
                                                    title="Read More">
                                                    Read More
                                                </a>
                                            </div>
                                        </div>

                                        <div class="velaBlogItem blogArticle">
                                            <div class="blogPostImage">
                                                <a href="blogs/news/anteposuerit-litterarum-formas-9.php"
                                                    title="Anteposuerit litterarum formas.">
                                                    <div class="p-relative">
                                                        <div class="product-card__image" style="padding-top: 64.375%">
                                                            <img class="product-card__img lazyload imgFlyCart"
                                                                data-src="https://cdn.shopify.com/s/files/1/1573/5553/articles/1_8c97c3ce-68a4-490a-b77b-ceece77b0926_360x.jpg?v=1511574604"
                                                                data-widths="[360,540,720,900,1080,1296,1728,1944,2808,4320]"
                                                                data-aspectratio="1.5533980582524272"
                                                                data-ratio="1.5533980582524272" data-sizes="auto"
                                                                alt="Anteposuerit litterarum formas." />
                                                        </div>
                                                        <div class="placeholder-background placeholder-background--animation"
                                                            data-image-placeholder></div>
                                                    </div>
                                                </a>
                                            </div>

                                            <div class="blogPostContent">
                                                <div class="blogTitle">
                                                    <a href="blogs/news.php" title="News">News</a>
                                                </div>
                                                <h3 class="articleTitle">
                                                    <a href="blogs/news/anteposuerit-litterarum-formas-9.php">Anteposuerit
                                                        litterarum formas.</a>
                                                </h3>
                                                <div class="articleMeta d-flex">
                                                    <span class="articleAuthor"><span>By</span> Mr Admin</span>
                                                    <span>/</span>
                                                    <span class="articlePublish pull-left"><i class="fa fa-calendar-o"
                                                            aria-hidden="true"></i>November 06, 2017</span>
                                                </div>
                                                <div class="articleDesc">
                                                    Diga, Koma and Torus are three kitchen utensils
                                                    designed for Ommo, a new design-oriented...
                                                </div>
                                                <a class="btn btnBlogReadMore"
                                                    href="blogs/news/anteposuerit-litterarum-formas-9.php"
                                                    title="Read More">
                                                    Read More
                                                </a>
                                            </div>
                                        </div>

                                        <div class="velaBlogItem blogArticle">
                                            <div class="blogPostImage">
                                                <a href="blogs/news/anteposuerit-litterarum-formas-8.php"
                                                    title="Anteposuerit litterarum formas.">
                                                    <div class="p-relative">
                                                        <div class="product-card__image" style="padding-top: 64.375%">
                                                            <img class="product-card__img lazyload imgFlyCart"
                                                                data-src="https://cdn.shopify.com/s/files/1/1573/5553/articles/2_1e36e94b-9401-45f7-995d-860334be9f14_360x.jpg?v=1511574639"
                                                                data-widths="[360,540,720,900,1080,1296,1728,1944,2808,4320]"
                                                                data-aspectratio="1.5533980582524272"
                                                                data-ratio="1.5533980582524272" data-sizes="auto"
                                                                alt="Anteposuerit litterarum formas." />
                                                        </div>
                                                        <div class="placeholder-background placeholder-background--animation"
                                                            data-image-placeholder></div>
                                                    </div>
                                                </a>
                                            </div>

                                            <div class="blogPostContent">
                                                <div class="blogTitle">
                                                    <a href="blogs/news.php" title="News">News</a>
                                                </div>
                                                <h3 class="articleTitle">
                                                    <a href="blogs/news/anteposuerit-litterarum-formas-8.php">Anteposuerit
                                                        litterarum formas.</a>
                                                </h3>
                                                <div class="articleMeta d-flex">
                                                    <span class="articleAuthor"><span>By</span> Mr Admin</span>
                                                    <span>/</span>
                                                    <span class="articlePublish pull-left"><i class="fa fa-calendar-o"
                                                            aria-hidden="true"></i>November 06, 2017</span>
                                                </div>
                                                <div class="articleDesc">
                                                    Diga, Koma and Torus are three kitchen utensils
                                                    designed for Ommo, a new design-oriented...
                                                </div>
                                                <a class="btn btnBlogReadMore"
                                                    href="blogs/news/anteposuerit-litterarum-formas-8.php"
                                                    title="Read More">
                                                    Read More
                                                </a>
                                            </div>
                                        </div>

                                        <div class="velaBlogItem blogArticle">
                                            <div class="blogPostImage">
                                                <a href="blogs/news/anteposuerit-litterarum-formas-7.php"
                                                    title="Anteposuerit litterarum formas.">
                                                    <div class="p-relative">
                                                        <div class="product-card__image" style="padding-top: 64.375%">
                                                            <img class="product-card__img lazyload imgFlyCart"
                                                                data-src="https://cdn.shopify.com/s/files/1/1573/5553/articles/3_8c6e9a18-7a88-4e6e-8754-ad9cea2d6594_360x.jpg?v=1511574623"
                                                                data-widths="[360,540,720,900,1080,1296,1728,1944,2808,4320]"
                                                                data-aspectratio="1.5533980582524272"
                                                                data-ratio="1.5533980582524272" data-sizes="auto"
                                                                alt="Anteposuerit litterarum formas." />
                                                        </div>
                                                        <div class="placeholder-background placeholder-background--animation"
                                                            data-image-placeholder></div>
                                                    </div>
                                                </a>
                                            </div>

                                            <div class="blogPostContent">
                                                <div class="blogTitle">
                                                    <a href="blogs/news.php" title="News">News</a>
                                                </div>
                                                <h3 class="articleTitle">
                                                    <a href="blogs/news/anteposuerit-litterarum-formas-7.php">Anteposuerit
                                                        litterarum formas.</a>
                                                </h3>
                                                <div class="articleMeta d-flex">
                                                    <span class="articleAuthor"><span>By</span> Mr Admin</span>
                                                    <span>/</span>
                                                    <span class="articlePublish pull-left"><i class="fa fa-calendar-o"
                                                            aria-hidden="true"></i>November 06, 2017</span>
                                                </div>
                                                <div class="articleDesc">
                                                    Diga, Koma and Torus are three kitchen utensils
                                                    designed for Ommo, a new design-oriented...
                                                </div>
                                                <a class="btn btnBlogReadMore"
                                                    href="blogs/news/anteposuerit-litterarum-formas-7.php"
                                                    title="Read More">
                                                    Read More
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->