'use strict';
function myFunction() {
  document.getElementById('login').classList.add('hidden');
  document.getElementById('signup').classList.remove('hidden');
}
function myFunction1() {
  document.getElementById('login').classList.remove('hidden');
  document.getElementById('signup').classList.add('hidden');
}
